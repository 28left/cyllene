# mathwithjupyter
Teaching math (and more) with Jupyter notebooks
